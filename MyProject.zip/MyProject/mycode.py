import numpy as np
import pandas as pd

df = read_csv('data.csv')

df.head()
